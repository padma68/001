import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class LinkShortener {
    private static final String BASE_URL = "http://short.ly/";
    private static final String CHARACTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final int SHORT_KEY_LENGTH = 6;

    private Map<String, String> longToShort = new HashMap<>();
    private Map<String, String> shortToLong = new HashMap<>();
    private AtomicInteger counter = new AtomicInteger(1);

    public String shorten(String longUrl) {
        if (longToShort.containsKey(longUrl)) {
            return BASE_URL + longToShort.get(longUrl);
        }

        String shortKey;
        do {
            shortKey = encode(counter.getAndIncrement());
        } while (shortToLong.containsKey(shortKey));

        longToShort.put(longUrl, shortKey);
        shortToLong.put(shortKey, longUrl);
        return BASE_URL + shortKey;
    }

    public String expand(String shortUrl) {
        if (!shortUrl.startsWith(BASE_URL)) {
            return "Invalid short URL format.";
        }

        String shortKey = shortUrl.substring(BASE_URL.length());
        String longUrl = shortToLong.get(shortKey);
        return longUrl != null ? longUrl : "Short URL not found.";
    }

    private String encode(int num) {
        StringBuilder sb = new StringBuilder();
        while (num > 0) {
            sb.append(CHARACTERS.charAt(num % CHARACTERS.length()));
            num /= CHARACTERS.length();
        }
        while (sb.length() < SHORT_KEY_LENGTH) {
            sb.append('a');
        }
        return sb.reverse().toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LinkShortener shortener = new LinkShortener();

        while (true) {
            System.out.println("\n--- Link Shortener ---");
            System.out.println("1. Shorten URL");
            System.out.println("2. Expand URL");
            System.out.println("3. Exit");
            System.out.print("Choose: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter long URL: ");
                    String longUrl = scanner.nextLine();
                    System.out.println("Short URL: " + shortener.shorten(longUrl));
                    break;
                case 2:
                    System.out.print("Enter short URL: ");
                    String shortUrl = scanner.nextLine();
                    System.out.println("Original URL: " + shortener.expand(shortUrl));
                    break;
                case 3:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
